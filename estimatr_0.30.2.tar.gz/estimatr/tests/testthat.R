library(testthat)
library(estimatr)

test_check("estimatr")
